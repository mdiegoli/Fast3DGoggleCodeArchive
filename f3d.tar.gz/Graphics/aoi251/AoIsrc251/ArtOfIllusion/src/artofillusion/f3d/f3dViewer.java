/* Copyright (C) 1999-2005 by Peter Eastman

   This program is free software; you can redistribute it and/or modify it under the
   terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
   PARTICULAR PURPOSE.  See the GNU General Public License for more details. */

package artofillusion.f3d;

import artofillusion.animation.*;
import artofillusion.math.BoundingBox;
import artofillusion.math.Mat4;
import artofillusion.math.Vec3;
import artofillusion.object.*;
import artofillusion.ui.MeshEditController;
import artofillusion.*;
import buoy.widget.*;
import java.util.*;

/** MeshViewer is an abstract subclass of ViewerCanvas used for displaying Mesh objects. */

public class f3dViewer extends ViewerCanvas
{
  public static final int HANDLE_SIZE = 5;
  protected boolean showMesh, showSurface, showSkeleton;
  private int selectedJoint;
  private boolean detachSkeleton;
  private Vector lockedJoints;

  public f3dViewer(MeshEditController controller)
  {
	super(ModellingApp.getPreferences().getUseOpenGL() && isOpenGLAvailable());
    lockedJoints = new Vector();
    //Skeleton s = controller.getObject().object.getSkeleton();
  }
  
  /** Get the ID of the selected joint. */
  
  public int getSelectedJoint()
  {
    return selectedJoint;
  }
  
  /** Set the selected joint. */
  
  public void setSelectedJoint(int id)
  {
    selectedJoint = id;
  }
  
  /** Get an array of size [# joints in skeleton] specifyiing which ones are locked. */
  /*
  public boolean [] getLockedJoints()
  {
    Skeleton s = ((Mesh) getController().getObject().object).getSkeleton();
    if (s == null)
      return new boolean [0];
    boolean b[] = new boolean [s.getNumJoints()];
    for (int i = 0; i < lockedJoints.size(); i++)
    {
      int index = s.findJointIndex(((Integer) lockedJoints.elementAt(i)).intValue());
      if (index > -1 && index < b.length)
        b[index] = true;
    }
    return b;
  }
  */
  /** Determine whether a particular joint is locked. */
  
  public boolean isJointLocked(int id)
  {
    for (int i = 0; i < lockedJoints.size(); i++)
      if (((Integer) lockedJoints.elementAt(i)).intValue() == id)
        return true;
    return false;
  }
  
  /** Lock the joint with the specified ID. */
  
  public void lockJoint(int id)
  {
    Integer i = new Integer(id);
    if (lockedJoints.indexOf(i) == -1)
      lockedJoints.addElement(i);
  }
  
  /** Unlock the joint with the specified ID. */
  
  public void unlockJoint(int id)
  {
    lockedJoints.removeElement(new Integer(id));
  }

  /** Get whether the control mesh is visible. */
  
  public boolean getMeshVisible()
  {
    return showMesh;
  }

  /** Set whether the control mesh is visible. */
  
  public void setMeshVisible(boolean visible)
  {
    showMesh = visible;
  }
  
  /** Get whether the surface is visible. */
  
  public boolean getSurfaceVisible()
  {
    return showSurface;
  }

  /** Set whether the surface is visible. */
  
  public void setSurfaceVisible(boolean visible)
  {
    showSurface = visible;
  }
  
  /** Get whether the skeleton is visible. */
  
  public boolean getSkeletonVisible()
  {
    return showSkeleton;
  }

  /** Set whether the skeleton is visible. */
  
  public void setSkeletonVisible(boolean visible)
  {
    showSkeleton = visible;
  }
  
  /** Get whether the mesh is detached from the skeleton. */
  
  public boolean getSkeletonDetached()
  {
    return detachSkeleton;
  }

  /** Set whether the mesh is detached from the skeleton. */

  public void setSkeletonDetached(boolean detached)
  {
    detachSkeleton = detached;
  }
/*
@Override
protected void drawObject() {
	// TODO Auto-generated method stub
	
}
*/
@Override
public double[] estimateDepthRange()
{
  Mat4 toView = theCamera.getWorldToView();
  
  // Find the depth range for the object being edited.
  /*
  ObjectInfo info = getController().getObject();
  BoundingBox bounds = info.getBounds();
  double dx = bounds.maxx-bounds.minx;
  double dy = bounds.maxy-bounds.miny;
  double dz = bounds.maxz-bounds.minz;
  double size = 0.5*Math.sqrt(dx*dx+dy*dy+dz*dz);
  Vec3 origin = getDisplayCoordinates().fromLocal().times(bounds.getCenter());
  double depth = toView.times(origin).z;
  double min = depth-size, max = depth+size;

  // Now check the rest of the scene.
  
  if (showScene)
  {
    for (int i = 0; i < theScene.getNumObjects(); i++)
    {
      info = theScene.getObject(i);
      if (info == thisObjectInScene)
        continue;
      bounds = info.getBounds();
      dx = bounds.maxx-bounds.minx;
      dy = bounds.maxy-bounds.miny;
      dz = bounds.maxz-bounds.minz;
      size = 0.5*Math.sqrt(dx*dx+dy*dy+dz*dz);
      origin = info.coords.fromLocal().times(bounds.getCenter());
      if (!useWorldCoords)
        origin = thisObjectInScene.coords.toLocal().times(origin);
      depth = toView.times(origin).z;
      if (depth-size < min)
        min = depth-size;
      if (depth+size > max)
        max = depth+size;
    }
  }*/
  return new double [] {0, 10};
}
}