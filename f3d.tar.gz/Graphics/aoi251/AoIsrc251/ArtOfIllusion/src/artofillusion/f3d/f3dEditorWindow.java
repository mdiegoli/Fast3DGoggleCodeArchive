/*
 *  Copyright 2005 Author
 *  This program is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU General Public License as published by the Free Software
 *  Foundation; either version 2 of the License, or (at your option) any later version.
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 *  PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 */
package artofillusion.f3d;

import artofillusion.*;
import artofillusion.math.*;
import artofillusion.object.Mesh;
import artofillusion.object.ObjectInfo;
import artofillusion.ui.*;
import buoy.widget.*;
import buoy.event.*;

import java.awt.*;
import java.text.*;
import java.util.prefs.Preferences;

/**
 *  This is a simple class for displaying hello world in a dialog
 *
 *@author     Firstname Lastname
 *@created    10 july 2005
 */
class f3dEditorWindow extends BFrame implements EditingWindow, MeshEditController
{
	protected ToolPalette tools;
	protected f3dViewer theView;
	protected UndoStack undoStack;
    protected Preferences preferences;
    protected BorderContainer viewPanel;
    protected BMenuBar menubar;
    protected RowContainer controls;
    protected BorderContainer bc;
    /**
     *  Constructor for the f3dEditorWindow dialog
     *
     *@param  frame  Description of the Parameter
     */
    public f3dEditorWindow( BFrame frame )
    {
        super("f3d");
        setBounds(new java.awt.Rectangle(0,0,640,480));
        bc = new BorderContainer();
        bc.setDefaultLayout( new LayoutInfo( LayoutInfo.CENTER, LayoutInfo.NONE, new Insets( 5, 5, 5, 5 ), null ) );
        //controls = new RowContainer();
        theView = new f3dViewer(this);
        theView.setDrawFocus(false);
        theView.setDrawFocus(true);
        theView.setRenderMode(ViewerCanvas.RENDER_SMOOTH);
        //BButton quitButton = new BButton( "Chiudi little f3d!" );
        //bc.add( new BLabel( "little f3d!" ), BorderContainer.SOUTH );
        //bc.add( controls, BorderContainer.CENTER );
        //bc.add( new BLabel( "UP little f3d!" ), BorderContainer.NORTH );
        //bc.add(theView, BorderContainer.CENTER);
        //bc.add( new BLabel( "DOWN little f3d!" ), BorderContainer.SOUTH );
        //quitButton.addEventLink( CommandEvent.class, this, "doQuitButton" );
        setContent( bc );
        pack();
        initialize();
        setVisible( true );
    }

    protected void initialize()
    {
      undoStack = new UndoStack();
      if (ModellingApp.APP_ICON != null)
        setIcon(ModellingApp.APP_ICON);
      preferences = Preferences.userNodeForPackage(getClass()).node("f3dEditorWindow");
      //loadPreferences();
      addEventLink(WindowClosingEvent.class, new Object() {
        void processEvent()
        {
          BStandardDialog dlg = new BStandardDialog("", Translate.text("saveWindowChanges"), BStandardDialog.QUESTION);
          String options[] = new String [] {
            Translate.text("saveChanges"),
            Translate.text("discardChanges"),
            Translate.text("button.cancel")
          };
          int choice = dlg.showOptionDialog(f3dEditorWindow.this, options, options[0]);
          //if (choice == 0)
          //  doOk();
          //else if (choice == 1)
          //  doCancel();
        }
      });
      //numViewsShown = lastNumViews;
      //viewPanel = new BorderContainer();
      //viewsContainer = new FormContainer(new double [] {1, numViewsShown == 1 ? 0 : 1}, new double [] {1, numViewsShown == 1 ? 0 : 1});
      //viewsContainer.setDefaultLayout(new LayoutInfo(LayoutInfo.CENTER, LayoutInfo.BOTH));
      //theView = new ViewerCanvas();
      Object listen = new Object() {
        void processEvent(MousePressedEvent ev)
        {
          //for (int i = 0; i < theView.length; i++)
            //if (currentView != i && ev.getWidget() == theView[i])
            //{
              theView.setDrawFocus(false);
              theView.setDrawFocus(true);
              //currentView = i;
              updateMenus();
              updateImage();
            //}
        }
      };
      /*for (int i = 0; i < theView.length; i++)
      {
        viewPanel[i] = new BorderContainer() {
          public Dimension getPreferredSize()
          {
            return new Dimension(0, 0);
          }
          public Dimension getMinimumSize()
          {
            return new Dimension(0, 0);
          }
        };*/
        //controls = new RowContainer();
        //viewPanel.add(controls, BorderContainer.NORTH);
        //viewPanel.add(theView = createViewerCanvas(controls), BorderContainer.CENTER);
        //theView.setShowAxes(lastShowAxes);
        //theView.setGrid(lastGridSpacing, lastGridSubdivisions, lastShowGrid, lastSnapToGrid);
        //theView.addEventLink(MousePressedEvent.class, listen);
      //}
      //theView[1].setOrientation(2);
      //theView[2].setOrientation(4);
      //theView[3].setPerspective(true);
      //theView.setDrawFocus( true );
      //viewsContainer.add(viewPanel, 0, 0);
      //viewsContainer.add(viewPanel[1], 1, 0);
      //viewsContainer.add(viewPanel[2], 0, 1);
      //viewsContainer.add(viewPanel[3], 1, 1);
      //menubar = new BMenuBar();
      //setMenuBar(menubar);
    }
    
    /**
     *  Disposes of the window
     */
    private void doQuitButton()
    {
        dispose();
    }
    
    /** Get the ToolPalette for this window. */

    public ToolPalette getToolPalette()
    {
    	return tools;
    };

    /** Set the currently selected EditingTool. */
    
    public void setTool(EditingTool tool){};
    
    /** Set the text to display at the bottom of the window. */
    
    public void setHelpText(String text){};
    
    /** Get the BFrame for this EditingWindow: either the EditingWindow itself if it is a
        BFrame, or its parent if it is a BDialog. */
    
    public BFrame getFrame()
    {
    	return this;
    };

    /** Update the image displayed in this window. */

    

    /** Update which menus are enabled. */
    public synchronized void updateImage()
    {
      Rectangle bounds = getBounds();
      
      if (bounds.height <= 0)
        return;
      
      // Draw the grid, if necessary.
      
          // Parallel mode, so draw a flat grid.
      Camera theCamera = theView.getCamera();
      Vec2 v1 = theCamera.getViewToScreen().timesXY(new Vec3());
      Vec2 v2 = theCamera.getViewToScreen().timesXY(new Vec3(1.0, 1.0, 1.0));
      Vec2 v3 = theCamera.getWorldToScreen().timesXY(new Vec3());
      Vec3 horizDir = theCamera.getViewToWorld().timesDirection(Vec3.vx());
      Vec3 vertDir = theCamera.getViewToWorld().timesDirection(Vec3.vy());
      double horizSign, vertSign;
      if (Math.abs(horizDir.x) >= Math.abs(horizDir.y) && Math.abs(horizDir.x) >= Math.abs(horizDir.z))
        horizSign = (horizDir.x > 0 ? -1 : 1);
      else if (Math.abs(horizDir.y) >= Math.abs(horizDir.x) && Math.abs(horizDir.y) >= Math.abs(horizDir.z))
        horizSign = (horizDir.y > 0 ? -1 : 1);
      else
        horizSign = (horizDir.z > 0 ? 1 : -1);
      if (Math.abs(vertDir.x) >= Math.abs(vertDir.y) && Math.abs(vertDir.x) >= Math.abs(vertDir.z))
        vertSign = (vertDir.x > 0 ? -1 : 1);
      else if (Math.abs(vertDir.y) >= Math.abs(vertDir.x) && Math.abs(vertDir.y) >= Math.abs(vertDir.z))
        vertSign = (vertDir.y > 0 ? -1 : 1);
      else
        vertSign = (vertDir.z > 0 ? 1 : -1);
      int decimals = 2;
      NumberFormat format = NumberFormat.getNumberInstance();
      format.setMinimumFractionDigits(decimals);
      format.setMaximumFractionDigits(decimals);
      FontMetrics fm = getComponent().getFontMetrics(getComponent().getFont());
      int ascent = fm.getMaxAscent();
      double space = Math.abs(v1.x-v2.x);
      int origin = (int) v3.x;
      double pos = Math.IEEEremainder(v3.x, space);
      if (pos < 0.0)
        pos += space;
      int numberInterval = 1;
      if (space < 10)
        numberInterval = 5;
      else if (space < 25)
        numberInterval = 2;
      while ((int) pos < bounds.width)
      {
        int x = (int) pos;
        //drawVRule(x, (x == origin ? majorColor : minorColor));
        int lineIndex = (int) Math.round((pos-v3.x)/space);
        //if (lineIndex%numberInterval == 0)
          //drawString(format.format(lineIndex*1.0*horizSign), x+3, ascent+3, lineColor);
        pos += space;
      }
      space = Math.abs(v1.y-v2.y);
      origin = (int) v3.y;
      pos = Math.IEEEremainder(v3.y, space);
      if (pos < 0.0)
        pos += space;
      while ((int) pos < bounds.height)
      {
        int y = (int) pos;
        //drawHRule(y, (y == origin ? majorColor : minorColor));
        int lineIndex = (int) Math.round((pos-v3.y)/space);
        if (lineIndex%numberInterval == 0)
        //drawString(format.format(lineIndex*gridSpacing*vertSign), 3, y+ascent+3, lineColor);
        pos += space;
      }
        
        }
      
    
    public void updateMenus(){};
    
    /** Set the current UndoRecord for this EditingWindow. */
    
    public void setUndoRecord(UndoRecord command){};

    /** Register that the scene or object contained in the window has been modified. */
    
    public void setModified(){};
    
    /** Get the Scene which is being edited in this window.  If it is not a window for
        editing a scene, this should return null. */

    public Scene getScene()
    {
    	return ((f3dViewer) theView).getScene();
    };
    
    /** Get the ViewerCanvas in which editing is taking place.  This may return null
        if there is no ViewerCanvas. */
    
    public ViewerCanvas getView()
    {
    	return theView;
    };

    /** Confirm whether this window should be closed (possibly by displaying a message to the
        user), and then close it.  If the closing is canceled, this should return false. */

    public boolean confirmClose()
    {
    	return true;
    }

	public double getMeshTension() {
		// TODO Auto-generated method stub
		return 0;
	}

	public ObjectInfo getObject() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean[] getSelection() {
		// TODO Auto-generated method stub
		return null;
	}

	public int[] getSelectionDistance() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getSelectionMode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getTensionDistance() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void objectChanged() {
		// TODO Auto-generated method stub
		
	}

	public void setMesh(Mesh mesh) {
		// TODO Auto-generated method stub
		
	}

	public void setSelection(boolean[] selected) {
		// TODO Auto-generated method stub
		
	}

	public void setSelectionMode(int mode) {
		// TODO Auto-generated method stub
		
	};
    
}


