/* Copyright (C) 1999-2007 by Peter Eastman

   This program is free software; you can redistribute it and/or modify it under the
   terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
   PARTICULAR PURPOSE.  See the GNU General Public License for more details. */

package artofillusion.f3d;

import artofillusion.animation.*;
import artofillusion.math.*;
import artofillusion.object.*;
import artofillusion.ui.*;
import artofillusion.script.*;
import artofillusion.*;
import buoy.event.*;
import java.io.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;

/** CreateCurveTool is an EditingTool used for creating Curve objects. */

public class Fast3dTool extends EditingTool
{
  static int counter = 1;
  private ArrayList clickPoint, smoothness;
  private int smoothing, NumberOfPoints = 0, AddedPoints = 0;
  private Fast3d theCurve;
  private CoordinateSystem coords;
  private Point lastPoint;
  private ArrayList PointList;
  public TriangleMesh trianglemesh;
  public static final int HANDLE_SIZE = 3;

  public Fast3dTool(LayoutWindow fr)
  {
    super(fr);
    PointList = new ArrayList();
    /*if (smoothingMethod == Curve.INTERPOLATING)
      initButton("interpCurve");
    else
      initButton("approxCurve");
    smoothing = smoothingMethod;*/
    initButton("f3d:f3d");
  }

  public void activate()
  {
    super.activate();
    //theWindow.setHelpText(Translate.text("Fast3dTool.helpText"));
  }

  public void deactivate()
  {
    super.deactivate();
    addToScene();
  }

  public int whichClicks()
  {
    return ALL_CLICKS;
  }

  public String getToolTipText()
  {
    return Translate.text("Fast3dTool.tipText");
  }

  public boolean hilightSelection()
  {
    return (clickPoint == null);
  }
  
  public void drawOverlay(ViewerCanvas view)
  {
    Camera cam = view.getCamera();

    if (clickPoint == null)
      return;
    if (theCurve != null)
    {
      Mat4 trans = cam.getWorldToScreen().times(coords.fromLocal());
      WireframeMesh mesh = theCurve.getWireframeMesh();
      Point p[] = new Point [mesh.vert.length];
      for (int i = 0; i < p.length; i++)
      {
        Vec2 v = trans.timesXY(mesh.vert[i]);
        p[i] = new Point((int) v.x, (int) v.y);
      }
      for (int i = 0; i < mesh.from.length; i++)
        view.drawLine(p[mesh.from[i]], p[mesh.to[i]], ViewerCanvas.lineColor);
    }
    for (int i = 0; i < clickPoint.size(); i++)
      {
        //Vec3 pos = (Vec3) clickPoint.lastElement();
        Vec3 pos = (Vec3) clickPoint.get(i);
        Vec2 screenPos = view.getCamera().getWorldToScreen().timesXY(pos);
        view.drawBox((int) screenPos.x-HANDLE_SIZE/2, (int) screenPos.y-HANDLE_SIZE/2, HANDLE_SIZE, HANDLE_SIZE, ViewerCanvas.handleColor);
      }
  }

  public void AddCurvePoint(Point p)
  {
    PointList.add(p);
  }
  
  /* FAST3D version*/
  public void mousePressed(WidgetMouseEvent e, ViewerCanvas view)
  {
    Graphics g = view.getComponent().getGraphics();
    Point p;
    
    lastPoint = e.getPoint();
    g.drawOval(e.getX(), e.getY(), 2, 2); //it could be improved saving the coordinates into variables
    AddCurvePoint(lastPoint);
    NumberOfPoints++;
    AddedPoints++;
    g.dispose();
  }

/*AoI251  
  public void mousePressed(WidgetMouseEvent e, ViewerCanvas view)
  {
    if (clickPoint == null)
    {
      clickPoint = new ArrayList();
      smoothness = new ArrayList();
      view.repaint();
    }
    else
    {
      Vec3 pos = (Vec3) clickPoint.lastElement();
      Vec2 screenPos = view.getCamera().getWorldToScreen().timesXY(pos);
      view.drawDraggedShape(new Line2D.Float(new Point2D.Double(screenPos.x, screenPos.y), e.getPoint()));
    }
  }
*/
/*FAST3D version*/
 public void mouseDragged(WidgetMouseEvent e, ViewerCanvas view)
  {
    Graphics g = view.getComponent().getGraphics();
    Point p;
    
    lastPoint = e.getPoint();
    g.drawOval(e.getX(), e.getY(), 1, 1);
    if ( (NumberOfPoints % 2) == 0)
    {
        AddCurvePoint(lastPoint);
        AddedPoints++;	
    }
    NumberOfPoints++;
    g.dispose();
  }

 /*AoI251 
  public void mouseDragged(WidgetMouseEvent e, ViewerCanvas view)
  {
    if (clickPoint.size() == 0)
      return;
    Point dragPoint = e.getPoint();
    Vec3 pos = (Vec3) clickPoint.lastElement();
    Vec2 screenPos = view.getCamera().getWorldToScreen().timesXY(pos);
    view.drawDraggedShape(new Line2D.Float(new Point2D.Double(screenPos.x, screenPos.y), dragPoint));
  }
*/
 

  public void mouseReleased(WidgetMouseEvent e, ViewerCanvas view)
  {	
  	Graphics g = view.getComponent().getGraphics();
	Camera cam = view.getCamera();
	Point p, dragPoint = e.getPoint();
	Vec3 vertex[], orig, ydir, zdir;
	float s[];
	int i;	

    //if (clickPoint.size() > 1)
      //{
        // Create a new line object.  First, find all the points in world coordinates.
    // TODO: more than one stroke         
	vertex = new Vec3 [AddedPoints];
	s = new float [AddedPoints];
	orig = new Vec3();
	for (i = 0; i < PointList.size(); i++)
		{
		Point punto = (Point) PointList.get(i);
		vertex[i] = cam.convertScreenToWorld(punto, ModellingApp.DIST_TO_SCREEN);
		s[i] = (float)2;
		orig = orig.plus(vertex[i]);
		}
	orig = orig.times(1.0/vertex.length);
	
	// Find the object's coordinate system.
	
	ydir = cam.getViewToWorld().timesDirection(Vec3.vy());
	zdir = cam.getViewToWorld().timesDirection(new Vec3(0.0, 0.0, -1.0));
	coords = new CoordinateSystem(orig, zdir, ydir);
		
	// Transform all of the vertices into the object's coordinate system.
		
	for (i = 0; i < PointList.size(); i++)
		{
		vertex[i] = coords.toLocal().times(vertex[i]);
		vertex[i].z = 0.0;  // Prevent round-off error.
		}
	
	float[] tmp = {1,1};
    theCurve = new Fast3d(vertex,tmp, 1, true);
	//setLastF3dCreated(theCurve);
	cam.setObjectTransform(coords.fromLocal());
	boolean selected[] = null;
	//trianglemesh = (TriangleMesh)extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),1,0.0,true);
	//trianglemesh.setSmoothingMethod(TriangleMesh.INTERPOLATING);
	//objectChanged(new ObjectInfo(extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),1,0.0,true),coords,"Meta" + counter++));
	//trianglemesh = trianglemesh.convertToTriangleMesh(0.1);
	trianglemesh = theCurve.fast3d(theWindow.getScene());
	//addToScene();
	//lw.executeScript(new File("/home/mu/graphics/Sculpt_2.5.bsh"));
	//((LayoutWindow) theWindow).getScene().getSelection()[]
	//trianglemesh = TriangleMesh.subdivideLoop(trianglemesh, selected, Double.MAX_VALUE);
	addToScene();
	//public TriMeshEditorWindow(EditingWindow parent, String title, ObjectInfo obj, Runnable onClose, boolean allowTopology)
	//Thread t = new Thread();
	//triEdit = new TriMeshEditorWindow(lw, "Meta", new ObjectInfo(extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),10,0.0,true),coords,"Meta" + counter++),t,true);
	
	//#1-TriangleMesh
    //#2-Extrude
	//#3-Edit->Approximating
	
	//lw.executeScript(new File("/home/mu/graphics/Sculpt_2.5.bsh")); 
	
	trianglemesh = null;
	//view.drawImage(g);
	drawOverlay(view);
	PointList.clear();
	AddedPoints = 0;
	NumberOfPoints = 0;
    g.dispose();
  }  
  
  //public void MouseMoved() ...
  /*
  public void keyPressed(KeyPressedEvent e, ViewerCanvas view)
  {
    if (e.getKeyCode() == KeyPressedEvent.VK_ENTER && theCurve != null)
      {
        theCurve.setClosed(e.isControlDown());
        addToScene();
      }
  }*/


 /* AoI251
  public void mouseReleased(WidgetMouseEvent e, ViewerCanvas view)
  {
    Camera cam = view.getCamera();
    Point dragPoint = e.getPoint();
    Vec3 vertex[], orig, ydir, zdir;
    float s[];

    if (e.getClickCount() != 2)
      {
        clickPoint.addElement(cam.convertScreenToWorld(dragPoint, ModellingApp.DIST_TO_SCREEN));
        smoothness.addElement(new Float(e.isShiftDown() ? 0.0f : 1.0f));
      }
    if (clickPoint.size() > 1)
      {
        // Create a new line object.  First, find all the points in world coordinates.
            
        vertex = new Vec3 [clickPoint.size()];
        s = new float [clickPoint.size()];
        orig = new Vec3();
        for (int i = 0; i < vertex.length; i++)
          {
            vertex[i] = (Vec3) clickPoint.elementAt(i);
            s[i] = ((Float) smoothness.elementAt(i)).floatValue();
            orig = orig.plus(vertex[i]);
          }
        orig = orig.times(1.0/vertex.length);

        // Find the object's coordinate system.

        ydir = cam.getViewToWorld().timesDirection(Vec3.vy());
        zdir = cam.getViewToWorld().timesDirection(new Vec3(0.0, 0.0, -1.0));
        coords = new CoordinateSystem(orig, zdir, ydir);
            
        // Transform all of the vertices into the object's coordinate system.
            
        for (int i = 0; i < vertex.length; i++)
          {
            vertex[i] = coords.toLocal().times(vertex[i]);
          }
        theCurve = new Curve(vertex, s, smoothing, false);
        if (e.getClickCount() == 2)
          {
            theCurve.setClosed(e.isControlDown());
            addToScene();
            return;
          }
        cam.setObjectTransform(coords.fromLocal());
      }
    theWindow.updateImage();
  }
  */
  /** When the user presses Enter, add the curve to the scene. */
  
  public void keyPressed(KeyPressedEvent e, ViewerCanvas view)
  {
    if (e.getKeyCode() == KeyPressedEvent.VK_ENTER && theCurve != null)
      {
        theCurve.setClosed(e.isControlDown());
        addToScene();
        e.consume();
      }
  }

  /** Add the curve to the scene. */
  
  private void addToScene()
  {
    boolean addCurve = (theCurve != null);
    if (addCurve)
      {
        ObjectInfo info = new ObjectInfo(theCurve, coords, "Curve "+(counter++));
        info.addTrack(new PositionTrack(info), 0);
        info.addTrack(new RotationTrack(info), 1);
        UndoRecord undo = new UndoRecord(theWindow, false);
        int sel[] = theWindow.getScene().getSelection();
        //((LayoutWindow) theWindow).addObject(info, undo);
        //((f3dEditorWindow) theWindow).addObject(info, undo);
        // TODO: draw process in a thread
        ((LayoutWindow) theWindow).addObject(info, undo);
        //undo.addCommand(UndoRecord.SET_SCENE_SELECTION, new Object [] {sel});
        //theWindow.setUndoRecord(undo);
        //((LayoutWindow) theWindow).setSelection(theWindow.getScene().getNumObjects()-1);
      }
    boolean addTri = (trianglemesh != null);
    if (addTri)
      {
        //ObjectInfo info = new ObjectInfo(trianglemesh, coords, "MetaF3d "+(counter++));
    	ObjectInfo info = new ObjectInfo(trianglemesh, coords, "MetaF3d "+(counter++));
    	info.addTrack(new PositionTrack(info), 0);
        info.addTrack(new RotationTrack(info), 1);
        UndoRecord undo = new UndoRecord(theWindow, false);
        //int sel[] = theWindow.getScene().getSelection();
        ((LayoutWindow) theWindow).addObject(info, undo);
        //undo.addCommand(UndoRecord.SET_SCENE_SELECTION, new Object [] {sel});
        //theWindow.setUndoRecord(undo);
        //((LayoutWindow) theWindow).setSelection(theWindow.getScene().getNumObjects()-1);
        //lw.setLastFast3dInfo(info);
      }
    clickPoint = null;
    smoothness = null;
    theCurve = null;
    coords = null;
    //if (addCurve && addTri)
      theWindow.updateImage();
  }
}

/*
 * //called after mouseReleased

  


  
  private void addToScene()
  {
    boolean addCurve = (theCurve != null);
    if (addCurve)
      {
        ObjectInfo info = new ObjectInfo(theCurve, coords, "CurveF3d "+(counter++));
        info.addTrack(new PositionTrack(info), 0);
        info.addTrack(new RotationTrack(info), 1);
        UndoRecord undo = new UndoRecord(theWindow, false);
        undo.addCommandAtBeginning(UndoRecord.SET_SCENE_SELECTION, new Object [] {theWindow.getScene().getSelection()});
        ((LayoutWindow) theWindow).addObject(info, undo);
        theWindow.setUndoRecord(undo);
        ((LayoutWindow) theWindow).setSelection(theWindow.getScene().getNumObjects()-1);
        lw.setLastFast3dInfo(info);
      }
    boolean addTri = (trianglemesh != null);
    if (addTri)
      {
        //ObjectInfo info = new ObjectInfo(trianglemesh, coords, "MetaF3d "+(counter++));
    	ObjectInfo info = new ObjectInfo(trianglemesh, coords, "MetaF3d "+(counter++));
    	info.addTrack(new PositionTrack(info), 0);
        info.addTrack(new RotationTrack(info), 1);
        UndoRecord undo = new UndoRecord(theWindow, false);
        undo.addCommandAtBeginning(UndoRecord.SET_SCENE_SELECTION, new Object [] {theWindow.getScene().getSelection()});
        ((LayoutWindow) theWindow).addObject(info, undo);
        theWindow.setUndoRecord(undo);
        ((LayoutWindow) theWindow).setSelection(theWindow.getScene().getNumObjects()-1);
        lw.setLastFast3dInfo(info);
      }
    clickPoint = null;
    smoothness = null;
    theCurve = null;
    //trianglemesh = null;
    coords = null;
    if (addCurve || addTri)
      theWindow.updateImage();
  }
  
 * 
 */