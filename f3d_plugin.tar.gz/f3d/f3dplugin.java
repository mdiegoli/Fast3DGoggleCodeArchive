
/*
 *  Copyright 2005 Author
 *  This program is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU General Public License as published by the Free Software
 *  Foundation; either version 2 of the License, or (at your option) any later version.
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 *  PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 */
package artofillusion.f3d;

import artofillusion.*;
import artofillusion.ui.*;
import artofillusion.object.*;
import artofillusion.math.*;
import artofillusion.texture.*;


/**
 *@author     Firstname Lastname
 *@created    10 juillet 2005
 */

public class f3dplugin implements ModellingTool
{
    /**
     *  instance this tool,load it in memory
     */

    public f3dplugin() {}


    /**
     *  Get the text that appear as the menu item.
     *
     *@return    The name value
     */
    public String getName()
    {
        return "f3d";
    }


    /**
     *  StarterKit Command selection.
     *
     *@param  window  LayoutWindow
     */
    public void commandSelected( LayoutWindow window )
    {
        //Scene scene = window.getScene();
        //etc.
        //let's print hello world for the time being.
        //new f3dEditorWindow( window );
        //this class should do no more because it's always loaded.
        //TriangleMesh cube = new Cube(1,1,1).convertToTriangleMesh(0.1);
        //ParameterValue[] value = cube.getParameterValues();
        //cube.setParameterValue(new TextureParameter(this,"fava3d",1,1,1), value);
        //ObjectInfo mesh = new ObjectInfo(cube, new CoordinateSystem(),"fava3d");
        //new TriMeshEditorWindow(window,"f3d",mesh, new Runnable(){ public void run (){}; }, true);
        //new artofillusion.f3d.F3dApp();
        new f3dApp();
    }
}

