/* Copyright (C) 1999-2006 by Peter Eastman

   This program is free software; you can redistribute it and/or modify it under the
   terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
   PARTICULAR PURPOSE.  See the GNU General Public License for more details. */

package artofillusion.f3d;

import artofillusion.animation.*;
import artofillusion.animation.distortion.*;
import artofillusion.image.*;
import artofillusion.math.*;
import artofillusion.object.*;
import artofillusion.script.*;
import artofillusion.texture.*;
import artofillusion.ui.*;
import artofillusion.keystroke.*;
import artofillusion.*;
import buoy.event.*;
import buoy.widget.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.util.prefs.*;
import java.util.*;
import java.util.List;

import buoyx.docking.*;

import javax.swing.text.*;
import javax.swing.*;

/** The LayoutWindow class represents the main window for creating and laying out scenes. */

public class f3dLayoutWindow extends LayoutWindow
{
  public f3dLayoutWindow(Scene s){
	  super(s);
  }
@Override  
  public void Layout(Scene s){
	setTheScene(s);
    //helpText = new BLabel();
    //theScore = new Score(this);
    setUndoStack(new UndoStack());
    setSceneChangedEvent(new SceneChangedEvent(this));
    //createItemList();

    // Create the four SceneViewer panels.

    setTheView(new SceneViewer [1]);
    setViewPanel(new BorderContainer [1]);
    RowContainer row;
    Object listen = new Object() {
      void processEvent(MousePressedEvent ev)
      {
        for (int i = 0; i < getTheView().length; i++)
          if (getCurrentView() != i && ev.getWidget() == getTheView()[i])
          {
            getTheView()[getCurrentView()].setDrawFocus(false);
            getTheView()[i].setDrawFocus(true);
            getDisplayItem()[0].setState(getTheView()[i].getRenderMode() == ViewerCanvas.RENDER_WIREFRAME);
            //displayItem[1].setState(theView[i].getRenderMode() == ViewerCanvas.RENDER_FLAT);
            //displayItem[2].setState(theView[i].getRenderMode() == ViewerCanvas.RENDER_SMOOTH);
            //displayItem[3].setState(theView[i].getRenderMode() == ViewerCanvas.RENDER_TEXTURED);
            setCurrentView(i);
            updateImage();
          }
      }
    };
    Object keyListener = new Object() {
      public void processEvent(KeyPressedEvent ev)
      {
        //handleKeyEvent(ev);
      }
    };
    //for (int i = 0; i < 4; i++)
    for (int i = 0; i < 1; i++)
    {
      getViewPanel()[i] = new BorderContainer();/* {
        public Dimension getPreferredSize()
        {
          return new Dimension(0, 0);
        }
        public Dimension getMinimumSize()
        {
          return new Dimension(0, 0);
        }
      };*/
      //viewPanel[i].add(row = new RowContainer(), BorderContainer.NORTH);
      row=new RowContainer();
      getViewPanel()[i].add(getTheView()[i] = new SceneViewer(getTheScene(), row, this), BorderContainer.CENTER);
      //theView[i].setGrid(theScene.getGridSpacing(), theScene.getGridSubdivisions(), theScene.getShowGrid(), theScene.getSnapToGrid());
      getTheView()[i].addEventLink(MousePressedEvent.class, listen);
      getTheView()[i].addEventLink(KeyPressedEvent.class, keyListener);
      getTheView()[i].setPopupMenuManager(this);
    }
    //theView[1].setOrientation(2);
    //theView[2].setOrientation(4);
    //theView[3].setOrientation(6);
    //theView[3].setPerspective(true);
    //theView[currentView].setDrawFocus(true);
    //viewsContainer = new FormContainer(new double [] {1, 1}, new double [] {1, 1});
    //viewsContainer.setDefaultLayout(new LayoutInfo(LayoutInfo.CENTER, LayoutInfo.BOTH, null, null));
    //viewsContainer.add(viewPanel[0], 0, 0);
    //viewsContainer.add(viewPanel[1], 1, 0);
    //viewsContainer.add(viewPanel[2], 0, 1);
    //viewsContainer.add(viewPanel[3], 1, 1);
    setCenterContainer(new FormContainer(new double [] {0.0, 1.0}, new double [] {0.0, 1.0, 0.0, 0.0}));
    getCenterContainer().setDefaultLayout(new LayoutInfo(LayoutInfo.CENTER, LayoutInfo.BOTH, null, null));
    //centerContainer.add(viewsContainer, 1, 0, 1, 3);
    getCenterContainer().add(getViewPanel()[0], 1, 0, 1, 3);
    //getCenterContainer().add(getHelpText(), 0, 3, 2, 1);
    setDock(new DockingContainer [4]);
    getDock()[0] = new DockingContainer(getCenterContainer(), BTabbedPane.LEFT);
    //dock[0] = new DockingContainer(viewPanel[0], BTabbedPane.LEFT);
    getDock()[1] = new DockingContainer(getDock()[0], BTabbedPane.RIGHT);
    getDock()[2] = new DockingContainer(getDock()[1], BTabbedPane.BOTTOM);
    getDock()[3] = new DockingContainer(getDock()[2], BTabbedPane.TOP);
    setContent(getDock()[3]);
    for (int i = 0; i < getDock().length; i++)
    {
    	getDock()[i].setHideSingleTab(true);
    	getDock()[i].addEventLink(DockingEvent.class, this, "dockableWidgetMoved");
      BSplitPane split = getDock()[i].getSplitPane();
      split.setContinuousLayout(true);
      split.setOneTouchExpandable(true);
      BTabbedPane.TabPosition pos = getDock()[i].getTabPosition();
      split.setResizeWeight(pos == BTabbedPane.TOP || pos == BTabbedPane.LEFT ? 1.0 : 0.0);
      split.addEventLink(ValueChangedEvent.class, this, "updateMenus");
      split.addEventLink(ValueChangedEvent.class, this, "updateMenus");
    }
    f3dObjectPropertiesPanel propertiesPanel = new f3dObjectPropertiesPanel(this);
    BScrollPane propertiesScroller = new BScrollPane(propertiesPanel, BScrollPane.SCROLLBAR_NEVER, BScrollPane.SCROLLBAR_AS_NEEDED);
    propertiesScroller.getVerticalScrollBar().setUnitIncrement(10);
    propertiesScroller.setBackground(ThemeManager.getAppBackgroundColor());
    //getDockingContainer(BTabbedPane.RIGHT).addDockableWidget(new DefaultDockableWidget(itemTreeScroller, Translate.text("Objects")));
    //getDockingContainer(BTabbedPane.RIGHT).addDockableWidget(new DefaultDockableWidget(propertiesScroller, Translate.text("Properties")), 0, 1);
    //getDockingContainer(BTabbedPane.BOTTOM).addDockableWidget(new DefaultDockableWidget(theScore, Translate.text("Score")));
    setNumViewsShown(1);

    // Build the tool palette.

    setTools(new ToolPalette(2, 2));
    EditingTool metaTool, altTool, defaultTool;
    getTools().addTool(defaultTool = new Fast3dTool(this, Curve.INTERPOLATING));
    //tools.addTool(new RotateObjectTool(this));
    //tools.addTool(new ScaleObjectTool(this));
    //tools.addTool(new CreateCubeTool(this));
    //tools.addTool(new CreateSphereTool(this));
    //tools.addTool(new CreateCylinderTool(this));
    //tools.addTool(new CreateSplineMeshTool(this));
    //tools.addTool(new CreatePolygonTool(this));
    //tools.addTool(new CreateCameraTool(this));
    //tools.addTool(new CreateLightTool(this));
    //tools.addTool(new CreateCurveTool(this, Curve.INTERPOLATING));
    //tools.addTool(new CreateCurveTool(this, Curve.APPROXIMATING));
    getTools().addTool(metaTool = new MoveViewTool(this));
    getTools().addTool(altTool = new RotateViewTool(this));
    //tools.addTool(new Fast3dTool(this, Curve.APPROXIMATELY));
    getTools().selectTool(defaultTool);
    for (int i = 0; i < getTheView().length; i++)
    {
      getTheView()[i].setMetaTool(metaTool);
      getTheView()[i].setAltTool(altTool);
    }
    ((RotateViewTool) altTool).setUseSelectionCenter(true);

    // Fill in the left hand panel.

    getCenterContainer().add(getTools(), 0, 0);
    //centerContainer.add(timeFrameLabel = new BLabel(Translate.text("timeFrameLabel", "0.0", "0"), BLabel.CENTER), 0, 2, new LayoutInfo(LayoutInfo.CENTER, LayoutInfo.BOTH, null, null));

    // Build the menubar.

    setMenubar(new BMenuBar());
    //setMenuBar(menubar);
    //createFileMenu();
    //createEditMenu();
    //createObjectMenu();
    //createToolsMenu();
    //createAnimationMenu();
    //createSceneMenu();
    //createPopupMenu();
    //toggleViewsCommand();
    setKeyEventHandler( new KeyEventPostProcessor()
    {
      public boolean postProcessKeyEvent(KeyEvent e)
      {
        if (e.getID() != KeyEvent.KEY_PRESSED || e.isConsumed())
          return false;
        KeyPressedEvent press = new KeyPressedEvent(f3dLayoutWindow.this, e.getWhen(), e.getModifiersEx(), e.getKeyCode());
        handleKeyEvent(press);
        return (press.isConsumed());
      }
    });
    KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventPostProcessor(getKeyEventHandler());
    addEventLink(WindowActivatedEvent.class, this, "updateMenus");
    addEventLink(WindowClosingEvent.class, new Object() {
      void processEvent()
      {
        f3dApp.closeWindow(f3dLayoutWindow.this);
      }
    });
    //getItemTree().setPopupMenuManager(this);
    UIUtilities.applyDefaultFont(getContent());
    UIUtilities.applyDefaultBackground(getCenterContainer());
    //itemTreeScroller.setBackground(Color.white);
    //if (ModellingApp.APP_ICON != null)
      //setIcon(ModellingApp.APP_ICON);
    Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
    Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(getComponent().getGraphicsConfiguration());
    setBounds(new Rectangle(screenInsets.left, screenInsets.top, screenDim.width-screenInsets.left-screenInsets.right, screenDim.height-screenInsets.top-screenInsets.bottom));
    getTools().requestFocus();

}
@Override
public void addObject(ObjectInfo info, UndoRecord undo)
{
  getTheScene().addObject(info, undo);
  //itemTree.addElement(new ObjectTreeElement(info, itemTree));
  for (int i = 0; i < getTheView().length ; i++)
    getTheView()[i].rebuildCameraList();
  //getTheScore().rebuildList();
}

}