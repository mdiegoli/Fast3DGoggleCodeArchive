package artofillusion.f3d;

import java.util.List;

import javax.swing.SwingUtilities;

import buoy.widget.BStandardDialog;
import artofillusion.*;
import artofillusion.animation.PositionTrack;
import artofillusion.animation.RotationTrack;
import artofillusion.math.CoordinateSystem;
import artofillusion.math.RGBColor;
import artofillusion.math.Vec3;
import artofillusion.object.DirectionalLight;
import artofillusion.object.ObjectInfo;
import artofillusion.object.SceneCamera;
import artofillusion.ui.Translate;
import artofillusion.ui.UIUtilities;

public class f3dApp extends ArtOfIllusion{
	
	public f3dApp(){
	    final Scene theScene = new Scene();
	    CoordinateSystem coords = new CoordinateSystem(new Vec3(0.0, 0.0, Camera.DEFAULT_DISTANCE_TO_SCREEN), new Vec3(0.0, 0.0, -1.0), Vec3.vy());
	    ObjectInfo info = new ObjectInfo(new SceneCamera(), coords, "Camera 1");
	    info.addTrack(new PositionTrack(info), 0);
	    info.addTrack(new RotationTrack(info), 1);
	    theScene.addObject(info, null);
	    info = new ObjectInfo(new DirectionalLight(new RGBColor(1.0f, 1.0f, 1.0f), 0.8f), coords.duplicate(), "Light 1");
	    info.addTrack(new PositionTrack(info), 0);
	    info.addTrack(new RotationTrack(info), 1);
	    theScene.addObject(info, null);
	    //SwingUtilities.invokeLater(new Runnable() {
	      //public void run()
	      //{
	        f3dLayoutWindow fr = new f3dLayoutWindow(theScene);
	        windows.add(fr);
	        List plugins = PluginRegistry.getPlugins(Plugin.class);
	        for (int i = 0; i < plugins.size(); i++)
	        {
	          try
	          {
	            ((Plugin) plugins.get(i)).processMessage(Plugin.SCENE_WINDOW_CREATED, new Object [] {fr});
	          }
	          catch (Throwable tx)
	          {
	            String name = plugins.get(i).getClass().getName();
	            name = name.substring(name.lastIndexOf('.')+1);
	            new BStandardDialog("", UIUtilities.breakString(Translate.text("pluginNotifyError", name)), BStandardDialog.ERROR).showMessageDialog(null);
	          }
	        }
	        fr.setVisible(true);
	        fr.arrangeDockableWidgets();

	        // If the user opens a file immediately after running the program, close the empty
	        // scene window.

	        //for (int i = windows.size()-2; i >= 0; i--)
	          //if (windows.get(i) instanceof LayoutWindow)
	          //{
	            //LayoutWindow win = (LayoutWindow) windows.get(i);
	            //if (win.getScene().getName() == null && !win.isModified())
	              //closeWindow(win);
	          //}
	      //}
	    //});

		  }

	public static void main(String[] args){
		new f3dApp();
	}

}