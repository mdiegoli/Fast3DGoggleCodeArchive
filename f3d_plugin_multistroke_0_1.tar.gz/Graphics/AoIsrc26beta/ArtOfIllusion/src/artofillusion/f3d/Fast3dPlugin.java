/*  Fast3dPlugin.java  */

package artofillusion.f3d;

/*
 * Fast3dPlugin: plugin to quickly create 3d objects
 *
 * Copyright (C) 2008 Nik Trevallyn-Jones, Sydney Australia.
 *
 * Author: Nik Trevallyn-Jones, nik777@users.sourceforge.net
 * $Id: Exp $
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 */

import artofillusion.*;
import artofillusion.ui.*;

/**
 * Main "entry point" of the plugin.
 * Responds to event messages from the AOI core
 * 
 * @author nik
 *
 */
public class Fast3dPlugin implements Plugin
{
    /**
     * @implements {@link artofillusion.Plugin#processMessage(int, Object[])}
     */
    public void processMessage(int msg, Object[] arg)
    {
	switch (msg) {
	case Plugin.APPLICATION_STARTING:
	    break;
	    
	case Plugin.SCENE_WINDOW_CREATED:
	    LayoutWindow window = (LayoutWindow) arg[0];
            ToolPalette palette = window.getToolPalette();
            palette.addTool( 8, new Fast3dTool(window));
            palette.toggleDefaultTool();
            palette.toggleDefaultTool();
	    
	    break;
	}
    }
}