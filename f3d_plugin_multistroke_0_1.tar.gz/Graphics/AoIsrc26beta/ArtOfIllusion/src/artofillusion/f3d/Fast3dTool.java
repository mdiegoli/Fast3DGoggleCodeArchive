/* Copyright (C) 1999-2007 by Peter Eastman

   This program is free software; you can redistribute it and/or modify it under the
   terms of the GNU General Public License as published by the Free Software
   Foundation; either version 2 of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
   PARTICULAR PURPOSE.  See the GNU General Public License for more details. */

package artofillusion.f3d;

import artofillusion.animation.*;
import artofillusion.math.*;
import artofillusion.object.*;
import artofillusion.ui.*;
import artofillusion.script.*;
import artofillusion.*;
import buoy.event.*;
import java.io.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;


/** CreateCurveTool is an EditingTool used for creating Curve objects. */

public class Fast3dTool extends EditingTool
{
  static int counter = 1;
  private ArrayList clickPoint, smoothness;
  private int smoothing, NumberOfPoints = 0, AddedPoints = 0;
  int numb_inters=0;
  private Fast3d theCurve;
  private CoordinateSystem coords;
  private Point lastPoint;
  private ArrayList PointList,TmpList;
  public TriangleMesh trianglemesh;
  public static final int HANDLE_SIZE = 3;
  public boolean First_Stroke=true;
  double old_x, old_y;
  public Fast3dTool(LayoutWindow fr)
  {
    super(fr);
    PointList = new ArrayList();
    /*if (smoothingMethod == Curve.INTERPOLATING)
      initButton("interpCurve");
    else
      initButton("approxCurve");
    smoothing = smoothingMethod;*/
    java.awt.geom.Line2D.Double line = new java.awt.geom.Line2D.Double();
    boolean ret = line.linesIntersect(130,86,195,172,224,76,147,142);
    initButton("f3d:f3d");
  }

  public void activate()
  {
    super.activate();
    //theWindow.setHelpText(Translate.text("Fast3dTool.helpText"));
  }

  public void deactivate()
  {
    super.deactivate();
    addToScene();
  }

  public int whichClicks()
  {
    return ALL_CLICKS;
  }

  public String getToolTipText()
  {
    return Translate.text("Fast3dTool.tipText");
  }

  public boolean hilightSelection()
  {
    return (clickPoint == null);
  }
  
  public void drawOverlay(ViewerCanvas view)
  {
    Camera cam = view.getCamera();

    if (clickPoint == null)
      return;
    if (theCurve != null)
    {
      Mat4 trans = cam.getWorldToScreen().times(coords.fromLocal());
      WireframeMesh mesh = theCurve.getWireframeMesh();
      Point p[] = new Point [mesh.vert.length];
      for (int i = 0; i < p.length; i++)
      {
        Vec2 v = trans.timesXY(mesh.vert[i]);
        p[i] = new Point((int) v.x, (int) v.y);
      }
      for (int i = 0; i < mesh.from.length; i++)
        view.drawLine(p[mesh.from[i]], p[mesh.to[i]], ViewerCanvas.lineColor);
    }
    for (int i = 0; i < clickPoint.size(); i++)
      {
        //Vec3 pos = (Vec3) clickPoint.lastElement();
        Vec3 pos = (Vec3) clickPoint.get(i);
        Vec2 screenPos = view.getCamera().getWorldToScreen().timesXY(pos);
        view.drawBox((int) screenPos.x-HANDLE_SIZE/2, (int) screenPos.y-HANDLE_SIZE/2, HANDLE_SIZE, HANDLE_SIZE, ViewerCanvas.handleColor);
      }
  }

  public void AddCurvePoint(Point p)
  {
	Point p_tmp = p;
    PointList.add(p_tmp);
  }
  
  /* FAST3D version*/
  public void mousePressed(WidgetMouseEvent e, ViewerCanvas view)
  {
    Graphics g = view.getComponent().getGraphics();
    Point p;
    
    lastPoint = e.getPoint();
    old_x = lastPoint.getX();
    old_y = lastPoint.getY();
    g.drawOval(e.getX(), e.getY(), 2, 2); 
    AddCurvePoint(lastPoint);
    NumberOfPoints++;
    AddedPoints++;
    g.dispose();
  }

/*AoI251  
  public void mousePressed(WidgetMouseEvent e, ViewerCanvas view)
  {
    if (clickPoint == null)
    {
      clickPoint = new ArrayList();
      smoothness = new ArrayList();
      view.repaint();
    }
    else
    {
      Vec3 pos = (Vec3) clickPoint.lastElement();
      Vec2 screenPos = view.getCamera().getWorldToScreen().timesXY(pos);
      view.drawDraggedShape(new Line2D.Float(new Point2D.Double(screenPos.x, screenPos.y), e.getPoint()));
    }
  }
*/
/*FAST3D version*/
 public void mouseDragged(WidgetMouseEvent e, ViewerCanvas view)
  {
    Graphics g = view.getComponent().getGraphics();
    Point p;
    
    lastPoint = e.getPoint();
    //if ( (NumberOfPoints % 2) == 0)
    double dist = java.awt.geom.Point2D.distance(old_x, old_y, lastPoint.getX(), lastPoint.getY());
    //if(dist>100)
    if(dist>30)
    {
    	g.drawOval(e.getX(), e.getY(), 1, 1);
    	AddCurvePoint(lastPoint);
        AddedPoints++;
        old_x = lastPoint.getX();
        old_y = lastPoint.getY();
    }
    NumberOfPoints++;
    g.dispose();
  }

 /*AoI251 
  public void mouseDragged(WidgetMouseEvent e, ViewerCanvas view)
  {
    if (clickPoint.size() == 0)
      return;
    Point dragPoint = e.getPoint();
    Vec3 pos = (Vec3) clickPoint.lastElement();
    Vec2 screenPos = view.getCamera().getWorldToScreen().timesXY(pos);
    view.drawDraggedShape(new Line2D.Float(new Point2D.Double(screenPos.x, screenPos.y), dragPoint));
  }
*/
 

  public void mouseReleased(WidgetMouseEvent e, ViewerCanvas view)
  {	
  	Graphics g = view.getComponent().getGraphics();
	Camera cam = view.getCamera();
	Point p, dragPoint = e.getPoint();
	Vec3 vertex[], orig, ydir, zdir;
	float s[];
	//int i;	
    Object[] al,altmp=null;
    //vertex = new Vec3 [AddedPoints];
	s = new float [AddedPoints];
	orig = new Vec3();
	
    //if (clickPoint.size() > 1)
      //{
        // Create a new line object.  First, find all the points in world coordinates.
    // TODO: more than one stroke         
	al = PointList.toArray();
	if(TmpList != null)
		altmp = TmpList.toArray();
	//int[][][] prova = new int[1][2][3];
	//int prova_uno = prova.length;
	//int prova_due = prova[prova_uno-1].length;
	//int prova_tre = prova[prova_uno-1][prova_due-1].length;
	ArrayList<Intersection> res_inters = intersects(al,altmp);
	if(  (First_Stroke && res_inters.size() == 1) || (!First_Stroke && res_inters.size() == 2)){
		//fai f3d
		First_Stroke=false;
		Object[] ai = res_inters.toArray();
		double[][] cond = ((Intersection)ai[0]).getInters();
		ArrayList<Point> tmpArray=new ArrayList();
		for(int integer = (int)cond[0][0]+1;integer<=(int)cond[0][1];integer++){
			tmpArray.add((Point)PointList.get(integer));
		}
		tmpArray.add(new Point((int)cond[1][0],(int)cond[1][1]));
		vertex = new Vec3[tmpArray.size()];
		for (int i = 0; i < tmpArray.size(); i++)
		{
			Point punto = (Point) tmpArray.get(i);
			vertex[i] = cam.convertScreenToWorld(punto, ModellingApp.DIST_TO_SCREEN);
			s[i] = (float)2;
			orig = orig.plus(vertex[i]);
		}
		orig = orig.times(1.0/vertex.length);
		
		// Find the object's coordinate system.
		
		ydir = cam.getViewToWorld().timesDirection(Vec3.vy());
		zdir = cam.getViewToWorld().timesDirection(new Vec3(0.0, 0.0, -1.0));
		coords = new CoordinateSystem(orig, zdir, ydir);
			
		// Transform all of the vertices into the object's coordinate system.
			
		for (int i = 0; i < tmpArray.size(); i++)
		{
			vertex[i] = coords.toLocal().times(vertex[i]);
			vertex[i].z = 0.0;  // Prevent round-off error.
		}
		
		float[] tmp = {1,1};
	    theCurve = new Fast3d(vertex,tmp, 1, true);
		//setLastF3dCreated(theCurve);
		cam.setObjectTransform(coords.fromLocal());
		boolean selected[] = null;
		//trianglemesh = (TriangleMesh)extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),1,0.0,true);
		//trianglemesh.setSmoothingMethod(TriangleMesh.INTERPOLATING);
		//objectChanged(new ObjectInfo(extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),1,0.0,true),coords,"Meta" + counter++));
		//trianglemesh = trianglemesh.convertToTriangleMesh(0.1);
		trianglemesh = theCurve.fast3d(theWindow.getScene());
		//addToScene();
		//lw.executeScript(new File("/home/mu/graphics/Sculpt_2.5.bsh"));
		//((LayoutWindow) theWindow).getScene().getSelection()[]
		//trianglemesh = TriangleMesh.subdivideLoop(trianglemesh, selected, Double.MAX_VALUE);
		addToScene();
		
	}//fine if
	else{
		if(First_Stroke){
			TmpList=PointList;
		    PointList.clear();
		    First_Stroke=false;
		}else{
			double size;
			double[][] cond;
			Intersection[] ai = (Intersection[])res_inters.toArray();
			numb_inters=ai.length;
			//cond = ai[0].getInters();
			//appent curve to tmp
			//snodo[numb_inters][1]=lines_intersect(al[i+1].getX(), al[i+1].getY(), al[i+2].getX(), al[i+2].getY(), altmp[ii].getX(), altmp[ii].getY(), altmp[ii+1].getX(), altmp[ii+1].getY());
			 	
			//1-numero intersezioni 2-punto intersezione -> 3- coordinate inters 2 -indici intersezione -> valore indici intersezione
			ArrayList tmpArray=new ArrayList();
			if(numb_inters==0){
				cond = ai[0].getInters();
				for(int integer = 0;integer<cond[1][0];integer++){
					tmpArray.add(PointList.get(integer));
				}
				tmpArray.add(new Point((int)cond[0][0],(int)cond[0][1]));
			}else{
				for(int ciclo_inters=0;ciclo_inters<numb_inters;ciclo_inters++){
					//Algoritmo ottimizato fino a 2 intersezioni
					cond = ai[ciclo_inters].getInters();
					//size = cond[0][0] + (PointList.size()- cond[0][1]) + 1; 
					for(int integer = 0;integer<cond[1][0];integer++){
						tmpArray.add(PointList.get(integer));
					}
					tmpArray.add(new Point((int)cond[0][0],(int)cond[0][1]));
					for(int integer = (int)cond[1][0];integer<(PointList.size()-cond[1][1]);integer++){
						tmpArray.add(TmpList.get(integer));
					}
				}
				
			}
				
		}
			
		//burdiga con le liste
	}
	/*VECCHIO CODICE
	for (i = 0; i < PointList.size(); i++)
		{
		Point punto = (Point) PointList.get(i);
		vertex[i] = cam.convertScreenToWorld(punto, ModellingApp.DIST_TO_SCREEN);
		s[i] = (float)2;
		orig = orig.plus(vertex[i]);
		}
	orig = orig.times(1.0/vertex.length);
	
	// Find the object's coordinate system.
	
	ydir = cam.getViewToWorld().timesDirection(Vec3.vy());
	zdir = cam.getViewToWorld().timesDirection(new Vec3(0.0, 0.0, -1.0));
	coords = new CoordinateSystem(orig, zdir, ydir);
		
	// Transform all of the vertices into the object's coordinate system.
		
	for (i = 0; i < PointList.size(); i++)
		{
		vertex[i] = coords.toLocal().times(vertex[i]);
		vertex[i].z = 0.0;  // Prevent round-off error.
		}
	
	float[] tmp = {1,1};
    theCurve = new Fast3d(vertex,tmp, 1, true);
	//setLastF3dCreated(theCurve);
	cam.setObjectTransform(coords.fromLocal());
	boolean selected[] = null;
	//trianglemesh = (TriangleMesh)extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),1,0.0,true);
	//trianglemesh.setSmoothingMethod(TriangleMesh.INTERPOLATING);
	//objectChanged(new ObjectInfo(extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),1,0.0,true),coords,"Meta" + counter++));
	//trianglemesh = trianglemesh.convertToTriangleMesh(0.1);
	trianglemesh = theCurve.fast3d(theWindow.getScene());
	//addToScene();
	//lw.executeScript(new File("/home/mu/graphics/Sculpt_2.5.bsh"));
	//((LayoutWindow) theWindow).getScene().getSelection()[]
	//trianglemesh = TriangleMesh.subdivideLoop(trianglemesh, selected, Double.MAX_VALUE);
	addToScene();
	//public TriMeshEditorWindow(EditingWindow parent, String title, ObjectInfo obj, Runnable onClose, boolean allowTopology)
	//Thread t = new Thread();
	//triEdit = new TriMeshEditorWindow(lw, "Meta", new ObjectInfo(extrudeMesh(theCurve.convertToTriangleMesh(0.1),coords,new Vec3(0,0,1),10,0.0,true),coords,"Meta" + counter++),t,true);
	
	//#1-TriangleMesh
    //#2-Extrude
	//#3-Edit->Approximating
	
	//lw.executeScript(new File("/home/mu/graphics/Sculpt_2.5.bsh")); 
	FINE VECCHIO CODICE*/
	trianglemesh = null;
	//view.drawImage(g);
	drawOverlay(view);
	PointList.clear();
	AddedPoints = 0;
	NumberOfPoints = 0;
    g.dispose();
  }  
  
  //public void MouseMoved() ...
  /*
  public void keyPressed(KeyPressedEvent e, ViewerCanvas view)
  {
    if (e.getKeyCode() == KeyPressedEvent.VK_ENTER && theCurve != null)
      {
        theCurve.setClosed(e.isControlDown());
        addToScene();
      }
  }*/

  public void keyPressed(KeyPressedEvent e, ViewerCanvas view)
  {
    if (e.getKeyCode() == KeyPressedEvent.VK_ENTER && theCurve != null)
      {
        theCurve.setClosed(e.isControlDown());
        addToScene();
        e.consume();
      }
  }

  /** Add the curve to the scene. */
  
  private void addToScene()
  {
    boolean addCurve = (theCurve != null);
    if (addCurve)
      {
        ObjectInfo info = new ObjectInfo(theCurve, coords, "Curve "+(counter++));
        info.addTrack(new PositionTrack(info), 0);
        info.addTrack(new RotationTrack(info), 1);
        UndoRecord undo = new UndoRecord(theWindow, false);
        int sel[] = theWindow.getScene().getSelection();
        //((LayoutWindow) theWindow).addObject(info, undo);
        //((f3dEditorWindow) theWindow).addObject(info, undo);
        // TODO: draw process in a thread
        ((LayoutWindow) theWindow).addObject(info, undo);
        //undo.addCommand(UndoRecord.SET_SCENE_SELECTION, new Object [] {sel});
        //theWindow.setUndoRecord(undo);
        //((LayoutWindow) theWindow).setSelection(theWindow.getScene().getNumObjects()-1);
      }
    boolean addTri = (trianglemesh != null);
    if (addTri)
      {
        //ObjectInfo info = new ObjectInfo(trianglemesh, coords, "MetaF3d "+(counter++));
    	ObjectInfo info = new ObjectInfo(trianglemesh, coords, "MetaF3d "+(counter++));
    	info.addTrack(new PositionTrack(info), 0);
        info.addTrack(new RotationTrack(info), 1);
        UndoRecord undo = new UndoRecord(theWindow, false);
        //int sel[] = theWindow.getScene().getSelection();
        ((LayoutWindow) theWindow).addObject(info, undo);
        //undo.addCommand(UndoRecord.SET_SCENE_SELECTION, new Object [] {sel});
        //theWindow.setUndoRecord(undo);
        //((LayoutWindow) theWindow).setSelection(theWindow.getScene().getNumObjects()-1);
        //lw.setLastFast3dInfo(info);
      }
    clickPoint = null;
    smoothness = null;
    theCurve = null;
    coords = null;
    //if (addCurve && addTri)
      theWindow.updateImage();
  }
  /*TODO
   * f3d algorithm to draw the stroke and create quickly the 3d object
   * -f3d,tmp
   *  MDo->f3d++
   *  MDr->f3d++
   *  MR->different thread when I check if there is a	n intersection point:if yes, intersection=1 && first_stroke-> lines_intersection->create a closed f3d with the intersection point as first point and last point
    *                                                                     if yes, intersection>1 && !first_stroke-> lines_intersection->create a closed f3d with the intersection point as first point and last point
    *                                                                     if not tmp += f3d; f3d = null
    * */
  //From graphics gems
  public double[] lines_intersect( double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4){

	  double a1, a2, b1, b2, c1, c2; /* Coefficients of line eqns. */
	  double r1, r2, r3, r4;                       /* 'Sign' values */
	  double denom, offset, num;                   /* Intermediate values */
	  /* Compute a1, b1, c1, where line joining points 1 and 2
	  * is "a1 x + b1 y + c1 = 0".
	  */
	  a1 = y2 - y1;
	  b1 = x1 - x2;
	  c1 = x2 * y1 - x1 * y2;
	  /* Compute r3 and r4.
	  */
	  r3 = a1 * x3 + b1 * y3 + c1;
	  r4 = a1 * x4 + b1 * y4 + c1;
	  /* Compute a2, b2, c2 */
	  a2 = y4 - y3;
	  b2 = x3 - x4;
	  c2 = x4 * y3 - x3 * y4;
	  /* Compute r1 and r2 */
	  r1 = a2 * x1 + b2 * y1 + c2;
	  r2 = a2 * x2 + b2 * y2 + c2;
	  /* Line segments intersect: compute intersection point.
	  */
	  denom = a1 * b2 - a2 * b1;
	  offset = denom < 0 ? - denom / 2 : denom / 2;
	  /* The denom/2 is to get rounding instead of truncating. It
	  * is added or subtracted to the numerator, depending upon the
	  * sign of the numerator.
	  */
	  double[] r=new double[2];
	  num = b1 * c2 - b2 * c1;
	  r[0] = ( num < 0 ? num - offset : num + offset ) / denom;
	  num = a2 * c1 - a1 * c2;
	  r[1] = ( num < 0 ? num - offset : num + offset ) / denom;
	  return r;
} /* lines_intersect */

  public ArrayList<Intersection> intersects(Object[] al,Object[] altmp) {
     int first_size, second_size=0,i,ii;
     //numero intersezioni,punto intersezione/indici intersezione,coordinate intersezione/valore indici intersezione
     double[][] snodo = new double[2][2];
     ArrayList<Intersection> al_inters = new ArrayList();
     java.awt.geom.Line2D.Double line = new java.awt.geom.Line2D.Double();
     //indici da usare per i cicli di ricerca
     first_size=al.length;
     
	 //boolean ret = java.awt.geom.Line2D.linesIntersect(1, 0, 1, 4, 2, 0, 2, 4);
		
     if(altmp != null)
    	 second_size=altmp.length;
     int primo_ciclo = first_size-1;
     //recursiveIntersection(al,altmp);
  	 for(i = 0;i<primo_ciclo;i++){
  		//line.setLine(((Point)al[i]).getX(),((Point)al[i]).getY(),((Point)al[i+1]).getX(),((Point)al[i+1]).getY());
  		if(second_size != 0){
 			 for(ii = 0; ii< second_size;ii++){
 				 //for(int ni = 0;ni<numb_inters;ni++){
 					//if(java.awt.geom.Line2D.linesIntersect(((Point)al[i]).getX(), 
					//			((Point)al[i]).getY(), 
					//			((Point)al[i+1]).getX(), 
					//			((Point)al[i+1]).getY(), 
					//			((Point)altmp[ii]).getX(), 
					//			((Point)altmp[ii]).getY(), 
					//			((Point)altmp[ii+1]).getX(), 
					//			((Point)altmp[ii+1]).getY()
					//			)){
 				 if(line.intersects(((Point)altmp[ii]).getX(), ((Point)altmp[ii]).getY(),((Point)altmp[ii+1]).getX(),((Point)altmp[ii+1]).getY())){
 								  snodo[1]=lines_intersect(((Point)al[i]).getX(), 
								  ((Point)al[i]).getY(), 
								  ((Point)al[i+1]).getX(), 
						          ((Point)al[i+1]).getY(), 
						          ((Point)altmp[ii]).getX(), 
						          ((Point)altmp[ii]).getY(), 
						          ((Point)altmp[ii+1]).getX(), 
						          ((Point)altmp[ii+1]).getY());
 						snodo[0][0]=i;
 						snodo[0][1]=ii;
 						al_inters.add(new Intersection(snodo));
 					}
 				 //}
 			 }
 		 }else{
 			try{
 				FileWriter fstream = new FileWriter("/home/mu/Graphics/aoi.log");
 			    BufferedWriter out = new BufferedWriter(fstream);
 			    for(int s = 0;s<al.length;s++)
 			    	out.write(new String( " Ciclo n."+ s +" "+((Point)al[s]).getX() +" "+ ((Point)al[s]).getY()));
 			        //out.write("Hello Java");
 			    //Close the output stream
 			    out.close();
 			    }catch (Exception e){//Catch exception if any
 			      System.err.println("Error: " + e.getMessage());
 			} 
 			for(ii = i+2; ii+1<= primo_ciclo;ii++){//TODO: SI PUO' RIDURRE IN UN CICLO SOLO
				//for(int ni = 0;ni<=numb_inters;ni++){
 					//boolean ret = java.awt.geom.Line2D.linesIntersect(((Point)al[ii]).getX(), ((Point)al[ii]).getY(), ((Point)al[ii+1]).getX(), ((Point)al[ii+1]).getY(),((Point)al[i]).getX(), ((Point)al[i]).getY(), ((Point)al[i+1]).getX(), ((Point)al[i+1]).getY());
					/*
 					double A =((Point)al[i]).getX();
					double B =((Point)al[i]).getY();
					double C =((Point)al[i+1]).getX();
					double D =((Point)al[i+1]).getY();
					double E =((Point)al[ii]).getX();
					double F =((Point)al[ii]).getY();
					double G =((Point)al[ii+1]).getX();
					double H =((Point)al[ii+1]).getY();
					*/
 					//if(java.awt.geom.Line2D.linesIntersect(((Point)al[i]).getX(), ((Point)al[i]).getY(), ((Point)al[i+1]).getX(), ((Point)al[i+1]).getY(), ((Point)al[ii]).getX(), ((Point)al[ii]).getY(), ((Point)al[ii+1]).getX(), ((Point)al[ii+1]).getY()) == true){
					//if((java.awt.geom.Line2D.linesIntersect(A, B, C, D, E, F, G, H) == false)){ 
					//TODO java.io.File ftry{
 			    // Create file 
 			    
 				//boolean intersezione = line.intersects(((Point)al[ii]).getX(), ((Point)al[ii]).getY(),((Point)al[ii+1]).getX(),((Point)al[ii+1]).getY());
 				boolean intersezione = java.awt.geom.Line2D.linesIntersect(((Point)al[i]).getX(), ((Point)al[i]).getY(), ((Point)al[i+1]).getX(), ((Point)al[i+1]).getY(), ((Point)al[ii]).getX(), ((Point)al[ii]).getY(), ((Point)al[ii+1]).getX(), ((Point)al[ii+1]).getY());    
 				if(intersezione){	
					snodo[1]=lines_intersect(((Point)al[i]).getX(), ((Point)al[i]).getY(), ((Point)al[i+1]).getX(), ((Point)al[i+1]).getY(), ((Point)al[ii]).getX(), ((Point)al[ii]).getY(), ((Point)al[ii+1]).getX(), ((Point)al[ii+1]).getY());
					 	snodo[0][0]=i+1;
	                    snodo[0][1]=ii+1;
	                    al_inters.add(new Intersection(snodo));
					}
				//} 
 				
			 }
 		 }
  	 }
  		 
  	 return al_inters;
  }
  
  void recursiveIntersection(Object[] al, Object[] altmp){
	  int first_size, second_size=0,i,ii;
	  
	  first_size = al.length;
	     
		 //boolean ret = java.awt.geom.Line2D.linesIntersect(1, 0, 1, 4, 2, 0, 2, 4);
			
     if(altmp != null)
    	 second_size=altmp.length;
     int primo_ciclo = first_size-1;
  }
}//end class



/*
class f3dDrawThread extends Thread {
	     Point[] al,al2;
         f3dDrawThread(ArrayList al) {
             this.al=(Point[])al.toArray();
         }
         
         f3dDrawThread(ArrayList al, ArrayList al2) {
        	 this.al=(Point[])al.toArray();
        	 this.al2=(Point[])al2.toArray();
         }
         public void run() {
             // compute primes larger than minPrime
             int first_size, second_size;
             first_size=al.length;
             if(al2 not null)//if the second stroke exists...
             second_size=al2.length;
        	 for(int i = 0;i<first_size;i++)
        		 if(second_size not null){
        			 for(int ii = 0; ii< second_size;ii++){
        				 if(java.awt.geom.Line2D.linesIntersect(al[], Y1, X2, Y2, X3, Y3, X4, Y4))
        			 }
        		 }
         }
     }
*/
class Intersection{
	private int X=0,Y=1,COORD_INDEX=0,INTERS_INDEX=1;
	private double[][] Inters = new double[2][2];
	
	public Intersection(double[][] param_inters){
		this.setInters(param_inters);
	}
	
	public int getX() {
		return X;
	}
	public void setX(int x) {
		X = x;
	}
	public int getY() {
		return Y;
	}
	public void setY(int y) {
		Y = y;
	}
	public int getCOORD_INDEX() {
		return COORD_INDEX;
	}
	public void setCOORD_INDEX(int coord_index) {
		COORD_INDEX = coord_index;
	}
	public int getINTERS_INDEX() {
		return INTERS_INDEX;
	}
	public void setINTERS_INDEX(int inters_index) {
		INTERS_INDEX = inters_index;
	}

	public double[][] getInters() {
		return Inters;
	}

	public void setInters(double[][] inters) {
		Inters = inters;
	}
}